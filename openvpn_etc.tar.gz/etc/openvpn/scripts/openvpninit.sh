#!/bin/bash
#初始化VPN证书配置 by liuwei mail al6008@163.com
source /etc/openvpn/scripts/config.sh
outdir=$(pwd)

cd "${key_tools_dir}"
source "${key_tools_dir}/vars"
cd "${key_tools_dir}"
rm -rf "${save_path}"
rm -f "${openvpn_user_file}"
./clean-all
export KEY_SIZE=2048
#export KEY_SIZE=1024
./pkitool --initca
sleep 1
source "${key_tools_dir}/vars"
./pkitool --server server
sleep 1
./pkitool --server test
export KEY_SIZE=2048
./build-dh
sleep 1
./revoke-full test
touch "${openvpn_user_file}"
/usr/local/openvpn2.3.18/sbin/openvpn --genkey --secret keys/ta.key

#创建一个账号密码证书
company_name=Client
openvpn_certificate=`cat \
    <(echo -e '<tls-auth>') \
    ${KEY_DIR}/ta.key \
    <(echo -e '</tls-auth>\n<ca>') \
    ${KEY_DIR}/ca.crt \
    <(echo -e '</ca>')`
create_openvpn_file


#权限初始化
chown openvpn.openvpn -R /etc/openvpn/ &>/dev/null
mkdir /var/log/openvpn/ccd -p
chown openvpn.openvpn -R  /var/log/openvpn/ccd
service openvpn restart
exit 0
