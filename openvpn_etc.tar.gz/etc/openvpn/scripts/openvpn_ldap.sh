#!/bin/bash
#openopen auth openldap by liuwei mail:al6008@163.com
LDAP_URL=ldaps://172.16.110.201
LDAP_BASE="ou=people,dc=arxan,dc=com"
LOG_FILE="/var/log/openvpn/openvpn_ldap_login.log"
TIME_STAMP=$(date "+%Y-%m-%d %T")
username=${username:-$1}
password=${password:-$2}
mkdir /etc/openvpn/logs/ -p
#mail
username=$(echo $username |awk -F '@' '{print $1}')
/usr/bin/ldapsearch -x '(&(objectClass=ldapPublicKey)(cn='"${username}"'))' 'cn' -Z -D "cn=${username},${LDAP_BASE}" -H ${LDAP_URL} -b "${LDAP_BASE}"  -w ${password} &>/dev/null
if [ $? -eq 0 ]; then
	echo "${TIME_STAMP}: Successful authentication: username=\"${username}\" client: ${untrusted_ip}:${untrusted_port}">> ${LOG_FILE}
 	exit 0
else
	echo "${TIME_STAMP}: Incorrect password: username=\"${username}\" client: ${untrusted_ip}:${untrusted_port}, password=\"${password}\"." >> ${LOG_FILE}
	exit 1
fi
exit 1
