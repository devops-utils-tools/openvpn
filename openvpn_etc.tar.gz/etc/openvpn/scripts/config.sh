#!/bin/bash
#openvpn_config BY:liuwei mail:al6008@163.com 
#openvpn_server_ip="api.arxanfintech.com:65419 api.arxanfintech.com:65420 api.arxanfintech.com:65421"
SERVER_IP=${SERVER_IP:-"api.arxanfintech.com:61888"}

openvpn_server_ip=${SERVER_IP}
bak_email=liuwei@arxanfintech.com

key_tools_dir=/etc/openvpn/easy-rsa-2.0
save_path=/etc/openvpn/OpenVpnClient
openvpn_user_file=/etc/openvpn/scripts/openvpn_user.txt
openvpn_pass=$(openssl rand -base64 18)

#openvpn 客户端配置文件
create_openvpn_file(){
for server_ip in ${openvpn_server_ip}
        do
        if [ -z "${server_info}" ];then
                server_info=$(echo  "remote ${server_ip}#")
        else
                server_info=$(echo  "${server_info} remote ${server_ip}#")
        fi
        done
cat > ${outdir}/${company_name}.ovpn <<EOF
#OpenVPN ${number} ${company_name} By:liuwei Mail:al6008@163.com
#Date $(date +"%F %T")
#Alias /etc/openvpn/client.conf
client
dev tun
proto ${OVPN_PRROTO}
$(echo "$server_info" |sed 's@#@\n@g' |sed 's@:@ @g' | sed 's@^ @@g'|sed '/^$/d' )
remote-random
resolv-retry infinite
resolv-retry 60
nobind
persist-key
persist-tun
remote-cert-tls server
key-direction 1
comp-lzo
verb 0
auth-user-pass
#auth-user-pass /etc/openvpn/my_user_pass.txt(第1行账号 第2行密码)
${openvpn_certificate}
EOF
}
